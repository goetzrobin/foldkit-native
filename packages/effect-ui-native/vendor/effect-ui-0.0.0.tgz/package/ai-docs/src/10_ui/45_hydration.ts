/**
 * @title Hydrating in the browser
 *
 * Hydrate what the server rendered with `HtmlHydrate`. This is the browser
 * entry module of the server-rendered app, served as `/client.js`.
 */
import { Router } from "@effect/ui"
import { BrowserRouter, HtmlHydrate } from "@effect/ui/html"
import { Effect } from "effect"
import { FetchHttpClient } from "effect/http"
import { App } from "./fixtures/App.ts"
import { AppRoute } from "./fixtures/routes.ts"

// Hydrate the same component with the same props, plus the server's state.
// An app that only ever mounts in the browser uses `BrowserHost.mount`, and
// doesn't carry hydration. `Router.props` reads the route from the browser's URL. Each instance then
// adopts the server's state, its Model and its query results, and its DOM
// nodes instead of rebuilding them. The query results the server shipped aren't
// fetched again.
//
// A Layer that can never be ready on the server, such as a live connection,
// is kept off it with `Component.provide(C, layer, { server: false })`. The
// server then renders that child's fallback and the client builds it fresh.
const hydrate = Effect.gen(function*() {
  const state = JSON.parse(document.getElementById("state")!.textContent!)
  const root = yield* HtmlHydrate.hydrateEffect(
    App,
    Router.props(AppRoute),
    document.getElementById("app")!,
    state
  )
  // `hydrateEffect` is `hydrate` as an Effect that returns the root. `adopted`
  // completes once every instance is live. Until then a waiting one is inert.
  yield* root.adopted
  return yield* Effect.never
}).pipe(
  Effect.scoped,
  Effect.provide([
    BrowserRouter.layer({ routes: AppRoute }),
    FetchHttpClient.layer
  ])
)

Effect.runFork(hydrate)
